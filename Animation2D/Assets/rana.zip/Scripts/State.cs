
public interface State
{
    void Enter();
    void Update();
    void Exit();
}